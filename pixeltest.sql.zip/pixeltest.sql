-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2013 at 05:41 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pixeltest`
--
CREATE DATABASE IF NOT EXISTS `pixeltest` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pixeltest`;

-- --------------------------------------------------------

--
-- Table structure for table `pixel`
--

DROP TABLE IF EXISTS `pixel`;
CREATE TABLE IF NOT EXISTS `pixel` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pixelName` varchar(50) NOT NULL,
  `type` enum('server','client') NOT NULL,
  `site` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pixel`
--

INSERT INTO `pixel` (`pid`, `pixelName`, `type`, `site`, `comment`) VALUES
(1, 'citrades - server', 'server', 'http://www.citrades.com', 'Test pixel for server side testing'),
(2, 'citrades - client', 'client', 'http://www.citrades.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `pixeldata`
--

DROP TABLE IF EXISTS `pixeldata`;
CREATE TABLE IF NOT EXISTS `pixeldata` (
  `propId` int(11) NOT NULL AUTO_INCREMENT,
  `pixelId` int(11) NOT NULL,
  `metaKey` varchar(255) NOT NULL,
  `metaValue` varchar(255) NOT NULL,
  PRIMARY KEY (`propId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pixeltrack`
--

DROP TABLE IF EXISTS `pixeltrack`;
CREATE TABLE IF NOT EXISTS `pixeltrack` (
  `pixelId` int(11) NOT NULL AUTO_INCREMENT,
  `clientIp` varchar(20) NOT NULL,
  `type` enum('server','client') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pixelId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pixeltrack`
--

INSERT INTO `pixeltrack` (`pixelId`, `clientIp`, `type`, `timestamp`) VALUES
(1, '127.0.0.1', 'server', '2013-11-17 07:40:24'),
(2, '127.0.0.1', 'server', '2013-11-17 07:40:26'),
(3, '127.0.0.1', 'server', '2013-11-17 07:49:14'),
(4, '127.0.0.1', 'server', '2013-11-17 07:52:25'),
(5, '127.0.0.1', 'server', '2013-11-17 07:52:54'),
(6, '127.0.0.1', 'server', '2013-11-18 13:06:13'),
(7, '127.0.0.1', 'server', '2013-11-18 13:06:32');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
